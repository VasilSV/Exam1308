package softuni.exam.config;

// TODO:
public class ApplicationBeanConfiguration {

}
